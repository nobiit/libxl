# LibXLPy:
A libxl python wrapper

# Installation:
python setup.py install

# Dependencies:
* libxl

# Usage:
See tests under `./tests` folder.
